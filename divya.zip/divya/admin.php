
<?php
// Starting session
session_start();
 
// Storing session data
$_SESSION["firstname"] = $_POST['username'];

include("db.php");

if(isset($_POST['submit']))
{
	$Username=$_POST['username'];
                                           
                     $password=$_POST['password'];
					 $cond = 'false';
					 $select_data = mysql_query("SELECT * from signupp WHERE username='divya' && password='goodgirl'");
					 while($export_data=mysql_fetch_assoc($select_data))
					 {$cond = 'true';
					 
					 header('location:admin.php');}
	 				 $select_data = mysql_query("SELECT * from signpp WHERE username='$Username' && password='$password'&&username!='satwikchinna' && password!='admin@stip'");
					 while($export_data=mysql_fetch_assoc($select_data))
					 {$cond = 'true';
					 
					 header('location:number.php');}
					 if($cond == 'false')
					 {
						  header('location:error.html'  );
					 }
}


?>