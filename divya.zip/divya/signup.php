<?php
if (isset($_POST['submit']))
    {      
    include 'db.php';

                    $username=$_POST['username'];
                                           
                    
                    
					
                    $password=$_POST['password'];
					$email=$_POST['email'];
					$phone=$_POST['phone'];
					 $company=$_POST['company'];
					
					 $address=$_POST['address'];
					 
					 

         mysql_query("INSERT INTO book_database(username,password,email,phone,company,address) 
         VALUES ('$username','$password','$email','$phone','$company','$address')"); 
		 header("location:success.html");
            }
?>
<html>
<body>