<?php
if (isset($_POST['submit']))
    {      
    include 'db2.php';

                    $name=$_POST['name'];
                                           
                    
                    
					
					$email=$_POST['email'];
					$phone=$_POST['phone'];
					$book=$_POST['book'];
					 
					
					 $address=$_POST['address'];
					 
					 

         mysql_query("INSERT INTO orders(name,email,phone,address,book) 
         VALUES ('$name','$email','$phone','$address','$book')"); 
		 header("location:odd.html");
            }
?>
``