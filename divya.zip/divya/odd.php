<?php
    session_start();
    if(!isset($_SESSION['username'])){
        header('Location: order.html');
    }
    else{
        echo "<p style='padding: 20px 0px 0px 0px ';>" ."Tqq!"."  ".$_SESSION['username']."</p>" ;
    }
?>

<html>
<head>
<style>
</head>
<body background="powder blue">
<h1><center>Ur order will be soon delivered to the address </center></h1>
</body>
</html>