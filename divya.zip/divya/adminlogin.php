<?php
include('db.php');
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$password=$_POST['password'];
mysql_connect("localhost","root","");
mysql_select_db("signup");

if($username=='divya' && $password=='admin@divya'){
$result=mysql_query("select * from signupp where username='divya' and password='admin@divya'") or die("failed to query database" -mysql_query());
$row=mysql_fetch_array($result);
	$cond='true';
	header('location:number.php');
}
else{
    header('location:register.html');
}
}
?>