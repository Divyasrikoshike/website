
<html>
<head>

</head>
<body background="admin.jpg";>
<h1><center>Hello Admin....!!</center></h1>
</body>

 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signup";
$count = 0;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT username, email FROM signupp";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo ' <font size=7px>';
	echo "<p align=\"CENTER\">signup details";
	echo ' </font>';
	echo '<br>';
	echo '<br>';
    while($row = $result->fetch_assoc()) { echo'<font size=4px>';
        echo "<p align=\"CENTER\">name: " . $row["username"]." <br> email: " . $row["email"];
		$count = $count+1;
		echo '</font>';
		echo '<br>';
    } 
} else {
    echo "0 results";
}


echo ' <font size=5px>';
echo "<p align=\"CENTER\">total signups:";
echo $count;
echo ' </font>';
	echo '<br>';
	echo '<br>';
	echo '<br>';
	?>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "order";
$count = 0;	
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT name,email,phone,address,book FROM orders";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo ' <font size=7px>';
	echo 'order details';
	echo ' </font>';
	echo '<br>';
	echo '<br>';
    while($row = $result->fetch_assoc()) { echo'<font size=4px';
        echo "<p align=\"CENTER\"> name: " . $row["name"]. " <br>email: " . $row["email"] ."<br>phone: " . $row["phone"] ."<br>address: " . $row["address"]."<br>book: " . $row["book"] ;
		$count = $count+1;
		echo '</font>';
		echo '<br>';
		echo'<br>';
    } 
} else {
    echo "0 results";
}


echo ' <font size=5px>';
echo "<p align=\"CENTER\">total orders:'";
echo $count;
echo ' </font>';
	echo '<br>';
	echo '<br>';
	echo '<br>';
$conn->close();

?>

</html>