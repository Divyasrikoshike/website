<?php
if (isset($_POST['submit']))
    {      
    include 'db1.php';

                    $username=$_POST['username'];
                                           
                    
                    
					
                    
					$email=$_POST['email'];
					$phone=$_POST['phone'];
					 
					
					 $message=$_POST['message'];
					 
					 

         mysql_query("INSERT INTO contactt(username,email,phone,message) 
         VALUES ('$username','$email','$phone','$message')"); 
		 header("location:register.html");
            }
?>
<html>
<body>