<?php
include('db.php');
if(isset($_POST['submit']))
{
$username=$_POST['username'];
$password=$_POST['password'];
mysql_connect("localhost","root","");
mysql_select_db("signup");
$result=mysql_query("select * from signupp where username='$username' and password='$password'") or die("failed to query database" -mysql_query());
$row=mysql_fetch_array($result);
$cond='false';
if($row['username']==$username && $row['password']==$password){
	$cond='true';
	header('location:log.html');
}
else{
    header('location:register.html');
}
}
?>