<html>
<head>
<link rel="stylesheet" type="tect/css" href="style5.css">
</head>
<body>
<div id="ff">
<form action="process.php" method="POST">
<p>
<label>username</label>
<input type="text" id="user" name="user" />
</p>
<p>
<label>password:</label>
<input type="password" id="pass" name="pass" />
</p>
<p>
<input type="submit" id="btn" value="login" />
</p>
</form>
</div>
</body>
<html>











